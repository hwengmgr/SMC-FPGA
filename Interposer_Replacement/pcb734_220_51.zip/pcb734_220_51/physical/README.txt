
TERADYNE FABRICATION INSTRUCTIONS

*******************************************************************************

E-mail all PCB Design Fabrication Issues to bareboard.support@teradyne.com
Include bare board P/N and indicate if job is Quick Turn in the subject.

*******************************************************************************
BARE BOARD P/N:       		REVISION:        	DATE: 
DESIGNER:			ENGINEER:
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
A. INSTRUCTIONS to Fabrication Vendor:

1. LIST INTENTIONAL SHORTS BY NET:

      none

2. LIST INTENTIONAL OPENS BY NET:

      none

3. LIST INTENTIONAL DANGLES/STUBS:
      LAYER #                 QUANTITY
      -------                 --------
      none

4. SPECIFY ROUT EDGE VIOLATIONS:

      none

5. EXPLAIN ANY INTENTIONAL FABRICATION VIOLATIONS AND/OR SPECIAL REQUIREMENTS:

      none
-------------------------------------------------------------------------------
Documentation and minor revision changes are noted in section B.5 below.
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
B. FOR TERADYNE INTERNAL USE ONLY:

1. LIST AND EXPLAIN INVALID, MODIFIED OR UNCHECKED SYMBOLS (Concept &
Allegro):

      none

2. NOTES FOR NEXT DESIGNER/REVUP's (- special routing, guarded signals,
list of approved untested nets, etc.):

      none

3. LIST WAIVERS AT SIGN-OFF:
      WHO                     DEPARTMENT              WHAT
      ---                     ----------              ----
      none

4. LIST DRC COUNT WITH EXPLANATION(S) BY GROUPING:
      QTY          EXPLANATION
      -----        --------------------------------------------
      none

5. DOCUMENT BARE BOARD POLICY CHANGES (INCLUDE ECO#, IF APPLICABLE.)
      none
