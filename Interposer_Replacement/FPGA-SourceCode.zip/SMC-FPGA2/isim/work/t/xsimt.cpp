static const char * HSimCopyRightNotice = "Copyright 2004-2005, Xilinx Inc. All rights reserved.";
#ifdef __MINGW32__
#include "xsimMinGW.h"
#else
#include "xsim.h"
#endif


static HSim__s6* IF0(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createworkMt(const char*);
    HSim__s6 *blk = createworkMt(label); 
    return blk;
}


static HSim__s6* IF1(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibMffsrce(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibMffsrce(label); 
    return blk;
}


static HSim__s6* IF2(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibMlatchsre(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibMlatchsre(label); 
    return blk;
}


static HSim__s6* IF3(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibMmux(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibMmux(label); 
    return blk;
}


static HSim__s6* IF4(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibMsffsrce(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibMsffsrce(label); 
    return blk;
}


static HSim__s6* IF5(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___a_n_d2(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___a_n_d2(label); 
    return blk;
}


static HSim__s6* IF6(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___b_p_a_d(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___b_p_a_d(label); 
    return blk;
}


static HSim__s6* IF7(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___b_u_f(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___b_u_f(label); 
    return blk;
}


static HSim__s6* IF8(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___b_u_f_g_m_u_x(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___b_u_f_g_m_u_x(label); 
    return blk;
}


static HSim__s6* IF9(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___f_f(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___f_f(label); 
    return blk;
}


static HSim__s6* IF10(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___f_f(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___f_f(label); 
    return blk;
}


static HSim__s6* IF11(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___i_n_v(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___i_n_v(label); 
    return blk;
}


static HSim__s6* IF12(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___i_p_a_d(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___i_p_a_d(label); 
    return blk;
}


static HSim__s6* IF13(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___l_a_t_c_h_e(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___l_a_t_c_h_e(label); 
    return blk;
}


static HSim__s6* IF14(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___l_a_t_c_h_e(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___l_a_t_c_h_e(label); 
    return blk;
}


static HSim__s6* IF15(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___l_u_t4(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___l_u_t4(label); 
    return blk;
}


static HSim__s6* IF16(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___m_u_x2(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___m_u_x2(label); 
    return blk;
}


static HSim__s6* IF17(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___m_u_x2(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___m_u_x2(label); 
    return blk;
}


static HSim__s6* IF18(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___o_b_u_f(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___o_b_u_f(label); 
    return blk;
}


static HSim__s6* IF19(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___o_b_u_f_t(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___o_b_u_f_t(label); 
    return blk;
}


static HSim__s6* IF20(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___o_n_e(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___o_n_e(label); 
    return blk;
}


static HSim__s6* IF21(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___o_p_a_d(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___o_p_a_d(label); 
    return blk;
}


static HSim__s6* IF22(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___p_u(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___p_u(label); 
    return blk;
}


static HSim__s6* IF23(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___s_f_f(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___s_f_f(label); 
    return blk;
}


static HSim__s6* IF24(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___s_f_f(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___s_f_f(label); 
    return blk;
}


static HSim__s6* IF25(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___x_o_r2(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___x_o_r2(label); 
    return blk;
}


static HSim__s6* IF26(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___z_e_r_o(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___z_e_r_o(label); 
    return blk;
}


static HSim__s6* IF27(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___z_e_r_o(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___z_e_r_o(label); 
    return blk;
}


static HSim__s6* IF28(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___x_o_r2(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___x_o_r2(label); 
    return blk;
}


static HSim__s6* IF29(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___s_f_f(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___s_f_f(label); 
    return blk;
}


static HSim__s6* IF30(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___p_u(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___p_u(label); 
    return blk;
}


static HSim__s6* IF31(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___o_p_a_d(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___o_p_a_d(label); 
    return blk;
}


static HSim__s6* IF32(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___o_n_e(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___o_n_e(label); 
    return blk;
}


static HSim__s6* IF33(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___o_b_u_f_t(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___o_b_u_f_t(label); 
    return blk;
}


static HSim__s6* IF34(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___o_b_u_f(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___o_b_u_f(label); 
    return blk;
}


static HSim__s6* IF35(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___m_u_x2(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___m_u_x2(label); 
    return blk;
}


static HSim__s6* IF36(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___l_u_t4(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___l_u_t4(label); 
    return blk;
}


static HSim__s6* IF37(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___l_a_t_c_h_e(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___l_a_t_c_h_e(label); 
    return blk;
}


static HSim__s6* IF38(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___i_p_a_d(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___i_p_a_d(label); 
    return blk;
}


static HSim__s6* IF39(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___i_n_v(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___i_n_v(label); 
    return blk;
}


static HSim__s6* IF40(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___f_f(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___f_f(label); 
    return blk;
}


static HSim__s6* IF41(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___b_u_f_g_m_u_x(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___b_u_f_g_m_u_x(label); 
    return blk;
}


static HSim__s6* IF42(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___b_u_f(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___b_u_f(label); 
    return blk;
}


static HSim__s6* IF43(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___b_p_a_d(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___b_p_a_d(label); 
    return blk;
}


static HSim__s6* IF44(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createsimprim_ver_auxlibM_x___a_n_d2(const char*);
    HSim__s6 *blk = createsimprim_ver_auxlibM_x___a_n_d2(label); 
    return blk;
}


static HSim__s6* IF45(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createworkMsmc__fpga(const char*);
    HSim__s6 *blk = createworkMsmc__fpga(label); 
    return blk;
}


static HSim__s6* IF46(HSim__s6 *Arch,const char* label,int nGenerics, 
va_list vap)
{
    extern HSim__s6 * createworkMglbl(const char*);
    HSim__s6 *blk = createworkMglbl(label); 
    return blk;
}

class _top : public HSim__s6 {
public:
    _top() : HSim__s6(false, "_top", "_top", 0, 0, HSim::VerilogModule) {}
    HSimConfigDecl * topModuleInstantiate() {
        HSimConfigDecl * cfgvh = 0;
        cfgvh = new HSimConfigDecl("default");
        (*cfgvh).registerFuseLibList("simprims_ver;unisims_ver;xilinxcorelib_ver");

        (*cfgvh).addVlogModule("work","t", (HSimInstFactoryPtr)IF0);
        (*cfgvh).addVlogModule("simprims_ver","ffsrce", (HSimInstFactoryPtr)IF1);
        (*cfgvh).addVlogModule("simprims_ver","latchsre", (HSimInstFactoryPtr)IF2);
        (*cfgvh).addVlogModule("simprims_ver","mux", (HSimInstFactoryPtr)IF3);
        (*cfgvh).addVlogModule("simprims_ver","sffsrce", (HSimInstFactoryPtr)IF4);
        (*cfgvh).addVlogModule("simprims_ver","X_AND2", (HSimInstFactoryPtr)IF5);
        (*cfgvh).addVlogModule("simprims_ver","X_BPAD", (HSimInstFactoryPtr)IF6);
        (*cfgvh).addVlogModule("simprims_ver","X_BUF", (HSimInstFactoryPtr)IF7);
        (*cfgvh).addVlogModule("simprims_ver","X_BUFGMUX", (HSimInstFactoryPtr)IF8);
        (*cfgvh).addVlogModule("simprims_ver","X_FF", (HSimInstFactoryPtr)IF9);
        (*cfgvh).addVlogModule("simprims_ver","X_FF", (HSimInstFactoryPtr)IF10);
        (*cfgvh).addVlogModule("simprims_ver","X_INV", (HSimInstFactoryPtr)IF11);
        (*cfgvh).addVlogModule("simprims_ver","X_IPAD", (HSimInstFactoryPtr)IF12);
        (*cfgvh).addVlogModule("simprims_ver","X_LATCHE", (HSimInstFactoryPtr)IF13);
        (*cfgvh).addVlogModule("simprims_ver","X_LATCHE", (HSimInstFactoryPtr)IF14);
        (*cfgvh).addVlogModule("simprims_ver","X_LUT4", (HSimInstFactoryPtr)IF15);
        (*cfgvh).addVlogModule("simprims_ver","X_MUX2", (HSimInstFactoryPtr)IF16);
        (*cfgvh).addVlogModule("simprims_ver","X_MUX2", (HSimInstFactoryPtr)IF17);
        (*cfgvh).addVlogModule("simprims_ver","X_OBUF", (HSimInstFactoryPtr)IF18);
        (*cfgvh).addVlogModule("simprims_ver","X_OBUFT", (HSimInstFactoryPtr)IF19);
        (*cfgvh).addVlogModule("simprims_ver","X_ONE", (HSimInstFactoryPtr)IF20);
        (*cfgvh).addVlogModule("simprims_ver","X_OPAD", (HSimInstFactoryPtr)IF21);
        (*cfgvh).addVlogModule("simprims_ver","X_PU", (HSimInstFactoryPtr)IF22);
        (*cfgvh).addVlogModule("simprims_ver","X_SFF", (HSimInstFactoryPtr)IF23);
        (*cfgvh).addVlogModule("simprims_ver","X_SFF", (HSimInstFactoryPtr)IF24);
        (*cfgvh).addVlogModule("simprims_ver","X_XOR2", (HSimInstFactoryPtr)IF25);
        (*cfgvh).addVlogModule("simprims_ver","X_ZERO", (HSimInstFactoryPtr)IF26);
        (*cfgvh).addVlogModule("simprims_ver","X_ZERO", (HSimInstFactoryPtr)IF27);
        (*cfgvh).addVlogModule("simprims_ver","X_XOR2", (HSimInstFactoryPtr)IF28);
        (*cfgvh).addVlogModule("simprims_ver","X_SFF", (HSimInstFactoryPtr)IF29);
        (*cfgvh).addVlogModule("simprims_ver","X_PU", (HSimInstFactoryPtr)IF30);
        (*cfgvh).addVlogModule("simprims_ver","X_OPAD", (HSimInstFactoryPtr)IF31);
        (*cfgvh).addVlogModule("simprims_ver","X_ONE", (HSimInstFactoryPtr)IF32);
        (*cfgvh).addVlogModule("simprims_ver","X_OBUFT", (HSimInstFactoryPtr)IF33);
        (*cfgvh).addVlogModule("simprims_ver","X_OBUF", (HSimInstFactoryPtr)IF34);
        (*cfgvh).addVlogModule("simprims_ver","X_MUX2", (HSimInstFactoryPtr)IF35);
        (*cfgvh).addVlogModule("simprims_ver","X_LUT4", (HSimInstFactoryPtr)IF36);
        (*cfgvh).addVlogModule("simprims_ver","X_LATCHE", (HSimInstFactoryPtr)IF37);
        (*cfgvh).addVlogModule("simprims_ver","X_IPAD", (HSimInstFactoryPtr)IF38);
        (*cfgvh).addVlogModule("simprims_ver","X_INV", (HSimInstFactoryPtr)IF39);
        (*cfgvh).addVlogModule("simprims_ver","X_FF", (HSimInstFactoryPtr)IF40);
        (*cfgvh).addVlogModule("simprims_ver","X_BUFGMUX", (HSimInstFactoryPtr)IF41);
        (*cfgvh).addVlogModule("simprims_ver","X_BUF", (HSimInstFactoryPtr)IF42);
        (*cfgvh).addVlogModule("simprims_ver","X_BPAD", (HSimInstFactoryPtr)IF43);
        (*cfgvh).addVlogModule("simprims_ver","X_AND2", (HSimInstFactoryPtr)IF44);
        (*cfgvh).addVlogModule("work","smc_fpga", (HSimInstFactoryPtr)IF45);
        (*cfgvh).addVlogModule("work","glbl", (HSimInstFactoryPtr)IF46);
        HSim__s5 * topvl = 0;
        extern HSim__s6 * createworkMt(const char*);
        topvl = (HSim__s5*)createworkMt("t");
        topvl->moduleInstantiate(cfgvh);
        addChild(topvl);
        extern HSim__s6 * createworkMglbl(const char*);
        topvl = (HSim__s5*)createworkMglbl("glbl");
        topvl->moduleInstantiate(cfgvh);
        addChild(topvl);
        return cfgvh;
}
};

main(int argc, char **argv) {
  HSimDesign::initDesign();
  globalKernel->getOptions(argc,argv);
  HSim__s6 * _top_i = 0;
  try {
    HSimConfigDecl *cfg;
 _top_i = new _top();
  cfg =  _top_i->topModuleInstantiate();
    return globalKernel->runTcl(cfg, _top_i, "_top", argc, argv);
  }
  catch (HSimError& msg){
    try {
      globalKernel->error(msg.ErrMsg);
      return 1;
    }
    catch(...) {}
      return 1;
  }
  catch (...){
    globalKernel->fatalError();
    return 1;
  }
}
