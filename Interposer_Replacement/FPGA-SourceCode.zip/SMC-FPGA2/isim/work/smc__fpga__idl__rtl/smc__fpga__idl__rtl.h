////////////////////////////////////////////////////////////////////////////////
//   ____  ____  
//  /   /\/   /  
// /___/  \  /   
// \   \   \/    
//  \   \        Copyright (c) 2003-2004 Xilinx, Inc.
//  /   /        All Right Reserved. 
// /___/   /\   
// \   \  /  \  
//  \___\/\___\ 
////////////////////////////////////////////////////////////////////////////////

#ifndef H_workMsmc__fpga__idl__rtl_H
#define H_workMsmc__fpga__idl__rtl_H

#ifdef _MSC_VER
#pragma warning(disable: 4355)
#endif

#ifdef __MINGW32__
#include "xsimMinGW.h"
#else
#include "xsim.h"
#endif

class workMsmc__fpga__idl__rtl : public HSim__s5{
public: 
    workMsmc__fpga__idl__rtl(const char *instname);
    ~workMsmc__fpga__idl__rtl();
    void setDefparam();
    void constructObject();
    void moduleInstantiate(HSimConfigDecl *cfg);
    void connectSigs();
    void reset();
    virtual void archImplement();
    HSim__s2 *driver_us283;
    HSim__s2 *driver_us157;
    HSim__s2 *driver_us89;
    HSim__s2 *driver_us29;
    HSim__s2 *driver_us55;
    HSim__s2 *driver_us245;
    HSim__s2 *driver_us114;
    HSim__s2 *driver_us13;
    HSim__s2 *driver_us86;
    HSim__s2 *driver_us39;
    HSim__s2 *driver_us263;
    HSim__s2 *driver_us132;
    HSim__s2 *driver_us64;
    HSim__s2 *driver_us174;
    HSim__s1 us[302];
    HSim__s3 uv[20];
};

#endif
